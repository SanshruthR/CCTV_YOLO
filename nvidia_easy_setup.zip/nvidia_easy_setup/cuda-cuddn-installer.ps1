# Check for Administrator Privileges
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "This script requires administrator privileges. Please run as administrator."
    pause
    exit 1
}

# Check for Internet Connection
if (-not (Test-Connection -ComputerName google.com -Count 1 -Quiet)) {
    Write-Host "No internet connection detected. Please check your connection and try again."
    pause
    exit 1
}

# Step 1: Check for Python Installation
Write-Host "Checking for Python installation..."
try {
    python --version
} catch {
    Write-Host "Python is not installed. Please install Python and try again."
    pause
    exit 1
}

# Step 2: Download CUDA Toolkit 11.8
Write-Host "Downloading NVIDIA CUDA Toolkit 11.8..."
$CUDA_URL = "https://developer.nvidia.com/cuda-11-8-0-download-archive"
$CUDA_PAGE_MSG = "To download CUDA, you need an NVIDIA account. Please create or log into your account:"
Write-Host $CUDA_PAGE_MSG
Write-Host "👉 Ctrl+Left Click to open: $CUDA_URL"
pause
Write-Host "After logging in and downloading the CUDA Toolkit, place the installer in this directory and press any key to continue."
pause

# Step 3: Install CUDA Toolkit
$CUDA_INSTALLER = "cuda-toolkit-11.8.exe"
if (-not (Test-Path "$PWD\$CUDA_INSTALLER")) {
    Write-Host "CUDA installer not found. Please download it from NVIDIA and place it in this directory."
    pause
    exit 2
}

Write-Host "Installing CUDA Toolkit 11.8..."
Start-Process -FilePath "$PWD\$CUDA_INSTALLER" -ArgumentList "--silent --toolkit --override" -Wait
if ($LASTEXITCODE -ne 0) {
    Write-Host "CUDA installation failed. Please check the installer and try again."
    pause
    exit 3
}

# Step 4: Verify CUDA Installation
try {
    nvcc --version
} catch {
    Write-Host "CUDA verification failed. Please ensure CUDA is installed correctly."
    pause
    exit 4
}

# Step 5: Download and Extract cuDNN
Write-Host "Downloading cuDNN for CUDA 11.8..."
$CUDNN_URL = "https://developer.nvidia.com/downloads/compute/cudnn/secure/8.9.6/local_installers/11.x/cudnn-windows-x86_64-8.9.6.50_cuda11-archive.zip"
$CUDNN_PAGE_MSG = "To download cuDNN, you need an NVIDIA account. Please create or log into your account:"
Write-Host $CUDNN_PAGE_MSG
Write-Host "👉 Ctrl+Left Click to open: $CUDNN_URL"
pause
Write-Host "After logging in and downloading cuDNN, place the ZIP file in this directory and press any key to continue."
pause

$CUDNN_ZIP = "cudnn.zip"
if (-not (Test-Path "$PWD\$CUDNN_ZIP")) {
    Write-Host "cuDNN file not found. Please download it from NVIDIA and place it in this directory."
    pause
    exit 5
}

Write-Host "Extracting cuDNN..."
Expand-Archive -Path "$PWD\$CUDNN_ZIP" -DestinationPath "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.8"
if (-not (Test-Path "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.8\bin\cudnn64_8.dll")) {
    Write-Host "cuDNN extraction failed. Please try again."
    pause
    exit 6
}

# Step 6: Download and Extract TensorRT
Write-Host "Downloading TensorRT 8.6 for CUDA 11.8..."
$TENSORRT_URL = "https://developer.nvidia.com/downloads/compute/machine-learning/tensorrt/secure/8.6.1/zip/TensorRT-8.6.1.6.Windows10.x86_64.cuda-11.8.zip"
$TENSORRT_PAGE_MSG = "To download TensorRT, you need an NVIDIA account. Please create or log into your account:"
Write-Host $TENSORRT_PAGE_MSG
Write-Host "👉 Ctrl+Left Click to open: $TENSORRT_URL"
pause
Write-Host "After logging in and downloading TensorRT, place the ZIP file in this directory and press any key to continue."
pause

$TENSORRT_ZIP = "tensorrt.zip"
if (-not (Test-Path "$PWD\$TENSORRT_ZIP")) {
    Write-Host "TensorRT file not found. Please download it from NVIDIA and place it in this directory."
    pause
    exit 7
}

Write-Host "Extracting TensorRT..."
Expand-Archive -Path "$PWD\$TENSORRT_ZIP" -DestinationPath "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.8"
if (-not (Test-Path "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.8\lib\nvinfer.dll")) {
    Write-Host "TensorRT extraction failed. Please try again."
    pause
    exit 8
}

# Step 7: Install TensorRT Python Bindings
Write-Host "Installing TensorRT Python bindings..."
pip install "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v11.8\python\tensorrt-8.6.1-cp311-none-win_amd64.whl"

# Step 8: Install CuPy
Write-Host "Installing CuPy for CUDA 11.8..."
pip install cupy-cuda11x

# Verify Installation
Write-Host "Verifying installation of CUDA, cuDNN, and TensorRT..."
try {
    nvcc --version
} catch {
    Write-Host "CUDA verification failed."
    pause
    exit 9
}
pip show cupy
pip show tensorrt

Write-Host "NVIDIA CUDA Toolkit, cuDNN, and TensorRT have been successfully installed!"
pause