# Setup Instructions

## Running Scripts in Administrator Mode

To ensure the installation scripts run correctly, please follow these steps to run them in administrator mode:

1. Open the Start menu and type `cmd`.
2. Right-click on `Command Prompt` and select `Run as administrator`.
3. Navigate to the directory containing the script using the `cd` command. For example:
    ```sh
    cd path\to\your\script\directory
    ```
4. Run the desired script. For example:
    ```sh
    amd-installer.bat
    ```

Make sure to follow these steps for each script you need to run:

- `amd_easy_setup/amd-installer.bat`
- `amd_easy_setup/visual-studio-installer.bat`
- `nvidia_easy_setup/cuda-cuddn-installer.ps1`
- `nvidia_easy_setup/nvidia-installer.bat`
- `nvidia_easy_setup/visual-studio-installer.bat`

Running these scripts with administrator privileges ensures they have the necessary permissions to install software and make system changes.

# if you have issues join the discord https://discord.fnbubbles420.org/